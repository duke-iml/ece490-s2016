# These are only some ideas for the functions to be implemented 



def convert_to_3D(depth, K):
    """
    Convert the raw depth input to 3D coordinates in the object frame using the
    camera parameters. 

    """
    # Generate the pixel coordinates (x,y)
    return 


    

def euclidean_distance_2(P1, P2):
    """
    Squared euclidean distance for 3D points
    """
    return 
    


def random_sampling(P1, probability):
    """
    Sample a list of points. If probability is 0, no sampling is done. If
    Probability is closer to 1, more sampling is done
    """
    return 


    
def get_closest_points_3d(P1, P2):
    """
    Compute the closest 3D points searching exhaustively. The output has
    the same dimension as P1 and matches it.
    """
    return

    

def substract_mean(point_list_in):
    """
    Return input-mean and the mean
    """
    return 
    

def threshold_closest_points(P1, P2, threshold):
    """
    Discard the pairs of points for which their mutual distance exceeds the
    predefined threshold
    """
    return 

    
    
def covariance3d(Points1, Points2):
    return 
