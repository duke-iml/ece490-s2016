from utils import *
from functions import *

object = "school_glue"
camera = 1
image  = 0

# Read the model and the raw point cloud
model_file = "data/models/"+object+"_model.json"
depth_file = "data/raw_depth/"+object+"/NP"+str(camera)+"_"+str(image)+".json"
model_full = get_reconstructed_model(model_file)
depth_full = get_raw_depth(depth_file)

# Convert the raw point cloud to 3D coordinates
K  = get_camera_parameters(depth_file)
# The following function should be implemented using the intrinsic parameters of
# the camera contained in the matrix K. Note that the zeros in the depth should
# be eliminated since they will generate useless points
clpoints_full  = convert_to_3D(depth_full, K)  # TODO


# Sample both maps to make the further computations faster



# Compute the minimum distance between the points



# Reject the outliers, for example, using a thresold or another method


# Compute the R and t matrices. The procedure can be similar as the one for the
# 2D images.






#opengl_plot = OpenGLPlot(model_full, clpoints_full)
#opengl_plot.initialize_main_loop()

