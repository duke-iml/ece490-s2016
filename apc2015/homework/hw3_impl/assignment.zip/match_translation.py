from utils import *
#from functions import *

object = "school_glue"
camera = 1
image  = 0

# Read the model and the raw point cloud
model_file = "data/models/"+object+"_model.json"
depth_file = "data/processed_depth/"+object+".json"
model_full = get_reconstructed_model(model_file)
clpoints_full = get_raw_depth(depth_file)


# Sample both maps to make the further computations faster



# Compute the minimum distance between the points



# Reject the outliers, for example, using a thresold or another method


# Compute the R and t matrices. The procedure can be similar as the one for the
# 2D images.








opengl_plot = OpenGLPlot(model_full, clpoints_full)
opengl_plot.initialize_main_loop()

# If matplot is available you can use it to visualize the points (but it not
# required) as in the commented line
# matplot_points(model_full, clpoints_out)
