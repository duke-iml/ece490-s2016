from PIL import Image
from pylab import *
from copy import deepcopy


def euclidean_distance_2(P1, P2):
    """
    Compute the Squared Euclidean distance between 2 2D points
    """
    d = 0
    return d


def get_closest_points_2d(P1, P2):
    """
    Compute the closest 2D points searching exhaustively. The output has
    the same dimension as P1 and matches it.
    Input points: [[x1,y1],[x2,y2],...]
    """
    P2match = 0
    return P2match


def threshold_closest_points(P1, P2, threshold):
    """
    Discard the pairs of points for which their mutual distance exceeds the
    predefined threshold
    Input points: [[x1,y1],[x2,y2],...]
    """
    P1_th = []; P2_th = []
    return P1_th, P2_th
    

def substract_mean(point_list):
    """
    Input list: ((x1,y1),(x2,y2),...)
    Return input-mean and the mean
    """
    # Input format: 
    sum_x = 0; sum_y = 0
    return point_list, [sum_x, sum_y]


def covariance2d(Points1, Points2):
    """
    Compute the covariance of points in 2D
    """
    H = 0
    return H



# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#                 MAIN PROGRAM
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

file_triangle1 = "data/2d/image_1.jpg"
file_triangle2 = "data/2d/image_2.jpg"

# Read the images and convert to gray scale
imageraw1 = array( Image.open(file_triangle1).convert('L') )
imageraw2 = array( Image.open(file_triangle2).convert('L') )

# Threshold the images
image1 = 1*(imageraw1>128)
image2 = 1*(imageraw2>128)

# Show the input images
figure(); gray()
subplot(2,2,1); imshow(imageraw1); title('triangle 1 original')
subplot(2,2,2); imshow(imageraw2); title('triangle 2 original')
subplot(2,2,3); imshow(image1); title('triangle 1 w threshold')
subplot(2,2,4); imshow(image2); title('triangle 2 w threshold')
show()

# We want to match the triangles (black points with values 0), so we need to get
# their coordinates and discard the points corresponding to the background
# (white points with value 1). Any format can be used for the list describing
# the points but the following is recommended: [[x1,y1],[x2,y2],[x3,y3],...]
triangle1 = []; triangle2 = []
# triangle1 and triangle2 should contain the selected points






# Find the closest points to triangle 1 by exhaustive search using the squared
# Euclidean distance
triangle2match = get_closest_points_2d(triangle1, triangle2)



# The matching pairs may contain irrelevant data. Keep only the matching points
# that are close enough within a threshold parameter
# Note that this can be done together with the previous function
threshold = 0
triangle1match, triangle2match = threshold_closest_points(triangle1,
                                                          triangle2match,
                                                          threshold)

# Center the resulting pairs substracting their means
triangle1match, mean1 = substract_mean(triangle1match)
triangle2match, mean2 = substract_mean(triangle2match)


# Find the rotation and translation 
# Create the covariance matrix and compute the rotation
H = covariance2d(triangle1match, triangle2match)
# Solve for R and t



# Apply the rotation and translation to the original triangle2 and check if it
# now coincides with triangle 1.



# Plots
# figure()
# plot(zip(*triangle1)[0], zip(*triangle1)[1], '.')
# plot(zip(*triangle2)[0], zip(*triangle2)[1], '.')
# xlabel('x [m]')
# ylabel('y [m]')
# plt.show()
